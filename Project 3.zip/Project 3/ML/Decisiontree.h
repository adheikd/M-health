#pragma once
#include <cstdarg>
namespace Eloquent {
    namespace ML {
        namespace Port {
            class DecisionTree {
                public:
                    /**
                    * Predict class for features vector
                    */
                    int predict(float *x) {
                        if (x[31] <= 6.234) {
                            if (x[2] <= -0.945) {
                                if (x[0] <= -1.013) {
                                    return 1;
                                }

                                else {
                                    if (x[8] <= 0.235) {
                                        return 3;
                                    }

                                    else {
                                        if (x[4] <= -0.61) {
                                            return 7;
                                        }

                                        else {
                                            if (x[8] <= 0.255) {
                                                return 6;
                                            }

                                            else {
                                                return 0;
                                            }
                                        }
                                    }
                                }
                            }

                            else {
                                if (x[0] <= -0.099) {
                                    if (x[26] <= -4.2) {
                                        if (x[22] <= -0.2) {
                                            return 6;
                                        }

                                        else {
                                            return 3;
                                        }
                                    }

                                    else {
                                        if (x[10] <= -0.235) {
                                            if (x[24] <= -2.921) {
                                                return 6;
                                            }

                                            else {
                                                if (x[5] <= -0.275) {
                                                    if (x[24] <= -2.232) {
                                                        return 2;
                                                    }

                                                    else {
                                                        return 3;
                                                    }
                                                }

                                                else {
                                                    return 1;
                                                }
                                            }
                                        }

                                        else {
                                            return 1;
                                        }
                                    }
                                }

                                else {
                                    if (x[6] <= -0.375) {
                                        if (x[33] <= -0.865) {
                                            return 6;
                                        }

                                        else {
                                            return 3;
                                        }
                                    }

                                    else {
                                        if (x[12] <= 1.021) {
                                            if (x[0] <= 0.634) {
                                                if (x[26] <= 0.7) {
                                                    if (x[23] <= -2.586) {
                                                        return 3;
                                                    }

                                                    else {
                                                        if (x[11] <= 8.403) {
                                                            if (x[18] <= 2.723) {
                                                                if (x[29] <= -10.761) {
                                                                    if (x[11] <= -0.049) {
                                                                        return 1;
                                                                    }

                                                                    else {
                                                                        return 2;
                                                                    }
                                                                }

                                                                else {
                                                                    return 1;
                                                                }
                                                            }

                                                            else {
                                                                return 2;
                                                            }
                                                        }

                                                        else {
                                                            return 4;
                                                        }
                                                    }
                                                }

                                                else {
                                                    return 5;
                                                }
                                            }

                                            else {
                                                if (x[32] <= 0.315) {
                                                    return 5;
                                                }

                                                else {
                                                    return 7;
                                                }
                                            }
                                        }

                                        else {
                                            if (x[19] <= 1.465) {
                                                if (x[12] <= 1.033) {
                                                    return 2;
                                                }

                                                else {
                                                    if (x[12] <= 1.038) {
                                                        return 1;
                                                    }

                                                    else {
                                                        if (x[16] <= -0.115) {
                                                            if (x[18] <= 1.123) {
                                                                return 3;
                                                            }

                                                            else {
                                                                return 7;
                                                            }
                                                        }

                                                        else {
                                                            return 0;
                                                        }
                                                    }
                                                }
                                            }

                                            else {
                                                if (x[6] <= -0.019) {
                                                    if (x[17] <= 0.688) {
                                                        return 2;
                                                    }

                                                    else {
                                                        return 1;
                                                    }
                                                }

                                                else {
                                                    if (x[10] <= 0.205) {
                                                        return 3;
                                                    }

                                                    else {
                                                        return 1;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        else {
                            if (x[9] <= -0.91) {
                                if (x[33] <= -0.965) {
                                    if (x[2] <= 0.833) {
                                        return 6;
                                    }

                                    else {
                                        return 7;
                                    }
                                }

                                else {
                                    if (x[3] <= -0.965) {
                                        if (x[1] <= 0.059) {
                                            return 7;
                                        }

                                        else {
                                            return 6;
                                        }
                                    }

                                    else {
                                        if (x[9] <= -0.965) {
                                            if (x[32] <= 3.115) {
                                                if (x[4] <= -0.83) {
                                                    return 7;
                                                }

                                                else {
                                                    return 2;
                                                }
                                            }

                                            else {
                                                return 6;
                                            }
                                        }

                                        else {
                                            if (x[26] <= 28.21) {
                                                return 7;
                                            }

                                            else {
                                                if (x[6] <= 0.187) {
                                                    return 6;
                                                }

                                                else {
                                                    return 7;
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            else {
                                if (x[1] <= 0.518) {
                                    if (x[34] <= -0.285) {
                                        if (x[27] <= -0.27) {
                                            if (x[6] <= 0.97) {
                                                if (x[12] <= 1.009) {
                                                    if (x[34] <= -0.315) {
                                                        if (x[3] <= -0.275) {
                                                            if (x[26] <= 10.762) {
                                                                if (x[35] <= 0.836) {
                                                                    if (x[22] <= -0.345) {
                                                                        return 6;
                                                                    }

                                                                    else {
                                                                        if (x[31] <= 121.192) {
                                                                            return 5;
                                                                        }

                                                                        else {
                                                                            return 6;
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[2] <= -0.72) {
                                                                        return 6;
                                                                    }

                                                                    else {
                                                                        if (x[8] <= 0.46) {
                                                                            return 5;
                                                                        }

                                                                        else {
                                                                            return 6;
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                if (x[25] <= 75.9) {
                                                                    if (x[12] <= 0.114) {
                                                                        if (x[3] <= -0.5) {
                                                                            return 2;
                                                                        }

                                                                        else {
                                                                            return 5;
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 6;
                                                                    }
                                                                }

                                                                else {
                                                                    return 5;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[27] <= -0.3) {
                                                                return 2;
                                                            }

                                                            else {
                                                                if (x[23] <= -1.158) {
                                                                    return 3;
                                                                }

                                                                else {
                                                                    return 4;
                                                                }
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        if (x[13] <= 0.193) {
                                                            if (x[13] <= 0.09) {
                                                                return 6;
                                                            }

                                                            else {
                                                                return 5;
                                                            }
                                                        }

                                                        else {
                                                            if (x[25] <= 72.343) {
                                                                if (x[3] <= -0.295) {
                                                                    return 6;
                                                                }

                                                                else {
                                                                    if (x[29] <= -0.413) {
                                                                        return 2;
                                                                    }

                                                                    else {
                                                                        return 5;
                                                                    }
                                                                }
                                                            }

                                                            else {
                                                                return 5;
                                                            }
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[8] <= -0.1) {
                                                        return 5;
                                                    }

                                                    else {
                                                        if (x[17] <= 1.43) {
                                                            return 6;
                                                        }

                                                        else {
                                                            if (x[32] <= -5.547) {
                                                                return 5;
                                                            }

                                                            else {
                                                                return 3;
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            else {
                                                return 6;
                                            }
                                        }

                                        else {
                                            if (x[5] <= 0.361) {
                                                if (x[1] <= 0.055) {
                                                    return 1;
                                                }

                                                else {
                                                    if (x[26] <= -13.405) {
                                                        return 5;
                                                    }

                                                    else {
                                                        if (x[29] <= 2.33) {
                                                            return 2;
                                                        }

                                                        else {
                                                            return 1;
                                                        }
                                                    }
                                                }
                                            }

                                            else {
                                                if (x[10] <= -0.13) {
                                                    return 2;
                                                }

                                                else {
                                                    if (x[13] <= 0.152) {
                                                        return 3;
                                                    }

                                                    else {
                                                        return 4;
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    else {
                                        if (x[2] <= -0.367) {
                                            if (x[19] <= 19.418) {
                                                if (x[8] <= 0.185) {
                                                    return 3;
                                                }

                                                else {
                                                    return 0;
                                                }
                                            }

                                            else {
                                                if (x[31] <= 69.35) {
                                                    if (x[6] <= 0.249) {
                                                        if (x[1] <= 0.079) {
                                                            return 3;
                                                        }

                                                        else {
                                                            return 2;
                                                        }
                                                    }

                                                    else {
                                                        if (x[12] <= 0.432) {
                                                            if (x[32] <= -1.242) {
                                                                return 6;
                                                            }

                                                            else {
                                                                return 0;
                                                            }
                                                        }

                                                        else {
                                                            return 2;
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[29] <= -0.683) {
                                                        return 4;
                                                    }

                                                    else {
                                                        return 3;
                                                    }
                                                }
                                            }
                                        }

                                        else {
                                            if (x[6] <= -0.995) {
                                                return 5;
                                            }

                                            else {
                                                if (x[28] <= -0.005) {
                                                    if (x[8] <= -0.85) {
                                                        return 4;
                                                    }

                                                    else {
                                                        if (x[13] <= 0.622) {
                                                            if (x[35] <= -1.956) {
                                                                if (x[31] <= 53.224) {
                                                                    return 1;
                                                                }

                                                                else {
                                                                    return 2;
                                                                }
                                                            }

                                                            else {
                                                                if (x[1] <= 0.063) {
                                                                    if (x[21] <= 0.025) {
                                                                        return 3;
                                                                    }

                                                                    else {
                                                                        if (x[34] <= 0.32) {
                                                                            return 1;
                                                                        }

                                                                        else {
                                                                            return 2;
                                                                        }
                                                                    }
                                                                }

                                                                else {
                                                                    if (x[30] <= 30.148) {
                                                                        if (x[29] <= -3.675) {
                                                                            return 4;
                                                                        }

                                                                        else {
                                                                            if (x[6] <= 0.68) {
                                                                                if (x[35] <= -0.862) {
                                                                                    if (x[26] <= -0.857) {
                                                                                        return 2;
                                                                                    }

                                                                                    else {
                                                                                        if (x[34] <= -0.145) {
                                                                                            return 3;
                                                                                        }

                                                                                        else {
                                                                                            return 4;
                                                                                        }
                                                                                    }
                                                                                }

                                                                                else {
                                                                                    return 2;
                                                                                }
                                                                            }

                                                                            else {
                                                                                return 4;
                                                                            }
                                                                        }
                                                                    }

                                                                    else {
                                                                        return 3;
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            return 4;
                                                        }
                                                    }
                                                }

                                                else {
                                                    if (x[28] <= 0.005) {
                                                        if (x[4] <= -0.125) {
                                                            return 2;
                                                        }

                                                        else {
                                                            if (x[31] <= 88.249) {
                                                                return 0;
                                                            }

                                                            else {
                                                                return 1;
                                                            }
                                                        }
                                                    }

                                                    else {
                                                        if (x[13] <= 0.243) {
                                                            if (x[31] <= 20.941) {
                                                                return 3;
                                                            }

                                                            else {
                                                                if (x[12] <= 0.952) {
                                                                    if (x[27] <= 0.09) {
                                                                        return 2;
                                                                    }

                                                                    else {
                                                                        return 1;
                                                                    }
                                                                }

                                                                else {
                                                                    return 5;
                                                                }
                                                            }
                                                        }

                                                        else {
                                                            if (x[21] <= -0.22) {
                                                                return 2;
                                                            }

                                                            else {
                                                                if (x[4] <= 0.065) {
                                                                    return 4;
                                                                }

                                                                else {
                                                                    if (x[3] <= 0.16) {
                                                                        return 5;
                                                                    }

                                                                    else {
                                                                        return 2;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                else {
                                    if (x[16] <= -0.005) {
                                        if (x[3] <= -0.295) {
                                            if (x[6] <= 0.877) {
                                                if (x[27] <= -0.28) {
                                                    if (x[7] <= 0.184) {
                                                        return 6;
                                                    }

                                                    else {
                                                        return 5;
                                                    }
                                                }

                                                else {
                                                    return 4;
                                                }
                                            }

                                            else {
                                                return 6;
                                            }
                                        }

                                        else {
                                            if (x[14] <= -0.197) {
                                                return 5;
                                            }

                                            else {
                                                if (x[30] <= -29.855) {
                                                    return 5;
                                                }

                                                else {
                                                    if (x[5] <= -1.948) {
                                                        if (x[24] <= -10.663) {
                                                            return 4;
                                                        }

                                                        else {
                                                            return 2;
                                                        }
                                                    }

                                                    else {
                                                        return 4;
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    else {
                                        if (x[16] <= 0.005) {
                                            if (x[22] <= -0.13) {
                                                return 4;
                                            }

                                            else {
                                                return 0;
                                            }
                                        }

                                        else {
                                            if (x[8] <= -0.895) {
                                                return 5;
                                            }

                                            else {
                                                if (x[13] <= 0.238) {
                                                    if (x[0] <= 0.028) {
                                                        return 3;
                                                    }

                                                    else {
                                                        return 2;
                                                    }
                                                }

                                                else {
                                                    return 4;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                protected:
                };
            }
        }
    }